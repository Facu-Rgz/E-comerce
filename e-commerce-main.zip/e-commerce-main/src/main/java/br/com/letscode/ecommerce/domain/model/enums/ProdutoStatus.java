package br.com.letscode.ecommerce.domain.model.enums;

public enum ProdutoStatus {
    ATIVO,INATIVO;
}
