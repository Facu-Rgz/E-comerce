# e-commerce
Projeto de estudo de sistemas, E-comerce

Projeto do modulo: 

 Construir um e-commerce onde seja possível gerenciar usuarios e produtos, Criar um carrinho de compras.  

Produtos:
    Cadastrar, alterar, listar, consultar e remover produtos

Usuarios : 
    Criar, alterar,listar consultar e remover ususarios.

Autenticar ususario

Carrinho de compras:
    Criar um carrinho de compras
    adicionar e remover produtos de um carrinho.

Requisitos:
 Testes
 conectar em uma base de dados postgres ( docker ou cloud)
 A aplicação deve salvar os dados na base de dados, podendo ser consultados após um restart da aplicacao.
 Construcao do projeto, estruturação.

----------Campos minimos ( os demais segue como em projeto de aula, ex produto)
Usuario:
id
nomeUsusario
nome:
data nascimento;
data criacao:
data alteracao

Carrinho:
Id carrinho
data criacao
data alteracao
Itens
